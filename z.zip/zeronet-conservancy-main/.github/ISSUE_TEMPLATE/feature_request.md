---
name: Feature request
about: Suggest an idea for ZeroNet
title: ''
labels: 'enhancement'
assignees: ''

---

*we have to rigid structure for feature requests right now, but please try to include important details on the matter*
